nihil-ticket-system
===================

By:
* Bryce Benn
* Kalev Kalda Sikes
* Ridhwaan Shakeel
* Wes Unwin

Descriptiony text is descriptiony

This project uses some libraries. These libraries should be in the libs/ folder.
 * JUnit : github.com/junit-team/junit/wiki/Download-and-Install