#ifndef asssets_debug_h
#define asssets_debug_h


#define debug_accounts				false
#define debug_tickets 				false
#define debug_transaction false
#define debug_transactions 	  	false
#define debug_buy					 	true

#define promptEnabled 				true
#define buy_ticketList 				true	


#endif

