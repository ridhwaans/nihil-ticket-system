#include <cstdio>
#include <string.h>
#include "../assets/globals.h"
#include "../assets/Ticket.h"
#include "../assets/commands.h"


using namespace std;

int main ( int argc, char** argv, char** envp) {

	cout << "Testing Sell.cpp..." << endl;

	
	cout << "Done." << endl;

	return 0;
}
