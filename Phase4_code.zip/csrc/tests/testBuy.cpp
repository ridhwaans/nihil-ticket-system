#include <cstdio>
#include <string.h>
#include "../assets/globals.h"
#include "../assets/Ticket.h"

using namespace std;

int main ( int argc, char** argv, char** envp) {

	cout << "Testing Buy.cpp..." << endl;

	
	cout << "Done." << endl;

	return 0;
}
